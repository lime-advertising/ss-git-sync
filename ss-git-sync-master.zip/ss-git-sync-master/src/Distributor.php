<?php

namespace SSGSM;

use RuntimeException;
use SSGSM\Support;
use SSGSM\Support\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Distributor {
    private array $settings;

    public function __construct(?array $settings = null) {
        $this->settings = $settings ?? Plugin::getSettings();
    }

    /**
     * @param string $token   Personal access token to distribute.
     * @param array  $targets Labels of secondary sites selected for update.
     * @return array{queued:int, success:array<string,string>, failed:array<string,string>, errors:array<string>}
     */
    public function pushToken(string $token, array $targets): array {
        $token = trim($token);
        if ($token === '') {
            throw new RuntimeException('Token missing.');
        }

        $targets = array_values(array_filter($targets, static fn($value) => is_string($value) && $value !== ''));
        if (empty($targets)) {
            throw new RuntimeException('No secondary sites selected.');
        }

        $index = [];
        foreach ($this->settings['secondaries'] ?? [] as $secondary) {
            if (!is_array($secondary) || empty($secondary['label'])) {
                continue;
            }
            $index[$secondary['label']] = $secondary;
        }

        $success = [];
        $failed = [];
        $errors = [];

        foreach ($targets as $label) {
            if (!isset($index[$label])) {
                $errors[] = sprintf(__('Unknown secondary site: %s', 'ssgs'), $label);
                continue;
            }

            $secondary = $index[$label];
            if (empty($secondary['url'])) {
                $errors[] = sprintf(__('Missing URL for %s.', 'ssgs'), $label);
                continue;
            }

            $secretPlain = Support\decrypt_secret($secondary['secret'] ?? '');
            if ($secretPlain === '') {
                $errors[] = sprintf(__('No shared secret stored for %s.', 'ssgs'), $label);
                continue;
            }

            $result = $this->dispatch($secondary, $token, $secretPlain);
            if (($result['status'] ?? '') === 'success') {
                $success[$label] = $result['message'] ?? '';
            } else {
                $failed[$label] = $result['message'] ?? __('Request failed.', 'ssgs');
            }
        }

        return [
            'queued'  => count($success) + count($failed),
            'success' => $success,
            'failed'  => $failed,
            'errors'  => $errors,
        ];
    }

    /**
     * Dispatch the token update request to the secondary site.
     *
     * @param array  $secondary Secondary site definition.
     * @param string $token     Token to transmit.
     * @param string $secret    Decrypted shared secret for the site.
     * @return array{status:string,message:string}
     */
    protected function dispatch(array $secondary, string $token, string $secret): array {
        $endpoint = $this->buildEndpoint($secondary['url'] ?? '');
        if ($endpoint === null) {
            $message = sprintf(__('Invalid URL for %s.', 'ssgs'), $secondary['label'] ?? __('Unnamed site', 'ssgs'));
            Logger::log('distributor', $message, 1);
            return ['status' => 'error', 'message' => $message];
        }

        $payload = [
            'token'        => $token,
            'source'       => home_url(),
            'dispatchedAt' => current_time('mysql'),
        ];
        $username = $this->settings['auth']['username'] ?? '';
        if (is_string($username) && $username !== '') {
            $payload['username'] = $username;
        }

        $args = [
            'timeout'   => 15,
            'headers'   => [
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
                'X-SSGS-Secret' => $secret,
            ],
            'body'      => wp_json_encode($payload),
            'sslverify' => apply_filters('ssgsm_distributor_sslverify', true, $secondary),
        ];

        $response = wp_remote_post($endpoint, $args);
        if (is_wp_error($response)) {
            $message = sprintf(
                __('Error contacting %s: %s', 'ssgs'),
                $secondary['label'],
                $response->get_error_message()
            );
            Logger::log('distributor', $message, 1);
            return ['status' => 'error', 'message' => $message];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = null;
        if ($body !== '') {
            $decoded = json_decode($body, true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
        }

        if ($code >= 200 && $code < 300) {
            $status  = is_array($data) ? ($data['status'] ?? 'success') : 'success';
            $message = is_array($data) ? ($data['message'] ?? '') : '';
            if ($status === 'success') {
                Logger::log(
                    'distributor',
                    sprintf(
                        'Token distribution succeeded for %s (%s). Status: %s',
                        $secondary['label'],
                        $endpoint,
                        $status
                    )
                );

                return [
                    'status'  => 'success',
                    'message' => $message !== '' ? $message : __('Token delivered.', 'ssgs'),
                ];
            }

            $responseMessage = $message !== '' ? $message : ($body !== '' ? $body : __('Remote site reported an error.', 'ssgs'));
            $logMessage = sprintf(
                __('Remote site %1$s reported an error: %2$s', 'ssgs'),
                $secondary['label'],
                $responseMessage
            );
            Logger::log('distributor', $logMessage, 1);

            return [
                'status'  => 'error',
                'message' => $responseMessage,
            ];
        }

        $responseMessage = is_array($data) ? ($data['message'] ?? '') : $body;
        $message = sprintf(
            __('Unexpected response from %1$s (HTTP %2$d). %3$s', 'ssgs'),
            $secondary['label'],
            $code,
            $responseMessage
        );
        Logger::log('distributor', $message, 1);

        return ['status' => 'error', 'message' => $message];
    }

    private function buildEndpoint(string $baseUrl): ?string {
        $baseUrl = trim($baseUrl);
        if ($baseUrl === '') {
            return null;
        }

        $parsed = wp_parse_url($baseUrl);
        if (empty($parsed['scheme'])) {
            $baseUrl = 'https://' . ltrim($baseUrl, '/');
        }

        return trailingslashit($baseUrl) . 'wp-json/ssgs/v1/token';
    }
}
